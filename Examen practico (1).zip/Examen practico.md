﻿![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.001.png)

**CARRERA** 

**ADMINISTRACIÓN DE INFRAESTRUCTURA Y PLATAFORMAS TECNOLÓGICAS MATERIA** 

**SISTEMAS OPERATIVOS I TEMA** 

**EXAMEN DE RECUPERACIÓN PRÁCTICO ESTUDIANTE** 

**ESTEBAN GEOVANNY MOLINA CHIRIBOGA** 

**DOCENTE** 

**ING. JONNATHAN F. NIVICELA A.** 

**Configurar el Servidor DNS con Bind** sudo dnf install bind bind-utils -y 

Editar el archivo de configuración de Bind 

![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.002.png)

Modificar las siguientes líneas para permitir consultas desde tu red local: options { 

`    `listen-on port 53 { 127.0.0.1; 192.168.1.19; }; 

`    `allow-query     { localhost; 192.168.1.0/24; }; 

`    `recursion yes; 

}; 

Editar el archivo de configuración de zonas: 

![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.003.png)

zone "examensistemas.com" IN { 

`    `type master; 

`    `file "/var/named/examensistemas.com.zone"; }; 

Crear el archivo de zona: 

![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.004.png)

Agregar las líneas 

$TTL 86400 

- IN  SOA  ns1.examensistemas.com. root.examensistemas.com. (         2025022001  ; Serial 

  `        `3600        ; Refresh 

  `        `1800        ; Retry 

  `        `604800      ; Expire 

  `        `86400 )     ; Minimum TTL 

IN  NS  ns1.examensistemas.com. 

ns1 IN  A   192.168.1.19 

www IN  A   192.168.1.19 

mail IN  A   192.168.1.19 

- IN  MX 10 mail.examensistemas.com. Guardar y cambia los permisos: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.005.png)

  Verificar que el DNS responde correctamente: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.006.jpeg)

  **Instalar y Configurar Postfix con Dovecot** 

  sudo dnf install postfix dovecot -y sudo systemctl enable --now postfix dovecot Editar la configuración de Postfix: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.007.png)

  Modificar las líneas 

  myhostname = mail.examensistemas.com 

  mydomain = examensistemas.com 

  myorigin = $mydomain 

  inet\_interfaces = all 

  inet\_protocols = ipv4 

  mydestination = $myhostname, localhost.$mydomain, localhost, $mydomain relay\_domains =  

  home\_mailbox = Maildir/ 

  Guardar y reinicia Postfix: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.008.png)

  Configurar Dovecot 

  Editar el archivo de configuración: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.009.png)

  Verificar la línea: protocols = imap pop3 lmtp Editae el archivo de autenticación: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.010.png)

  Descomentar la línea: disable\_plaintext\_auth = no Editar el archivo de configuración de correo: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.011.png)

  Verificar la línea: mail\_location = maildir:~/Maildir Reiniciar Dovecot: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.012.png)

  Abrir Puertos en el Firewall 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.013.png)

  **Creación de una nueva cuenta para un usuario y que el mismo puede acceder y enviar/recibir** 

  **correos** 

  Agregar el usuario y contraseña 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.014.png)

  Crear el buzon para “Juan” y configurar permisos 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.015.png)

  Verificamos que la carpeta se creo correctamente 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.016.png)

  **Verificacion de correo** 

  Primero una verificación que funcione el correo servidor Enviar un correo 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.017.png)

  Verificar que llego el correo 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.018.png)

  Usamos mutt para leer el correo 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.019.png)

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.020.png)

  **Prueba Cliente (Juan) – Servidor (molina)** Configuramos Thunderbird Servidor 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.021.jpeg)

  Configuramos ThunderBird Cliente 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.022.jpeg)

  Enviamos un correo de prueba desde Juan 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.023.png)

  Revisamos la bandeja en molina Verificado. 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.024.jpeg)

  **Servicio de Apache** Instalamos apache sudo dnf install httpd -y 

  Habilitamos para que inicie con el sistema sudo systemctl enable --now httpd Verificamos que esté corriendo: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.025.jpeg)

  Creamos un nuevo archivo de configuración para el sitio sudo nano /etc/httpd/conf.d/examensistemas.com.conf y agregamos lo siguiente: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.026.png)

  Creamos el directorio para el sitio web de prueba y cambiamos el propietario para evitar problemas de permisos 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.027.png)

  Creamos una página de prueba: 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.028.png)

  Editamos el archivo de configuración de la zona DNS sudo nano /var/named/examensistemas.com.zone Y agregamos las líneas señaladas 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.029.png)

  Guardamos y reniciamos el DNS 

  sudo systemctl restart named 

  Desde Windows comprobamos que el DNS responde correctamente 

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.030.png)

  Reiniciamos Apache para aplicar cambios sudo systemctl restart httpd 

  Accedemos desde el navegador Funciona correctamente con el dominio  

  ![](Aspose.Words.4018450b-18db-4e43-ae34-f1199eb61b44.031.png)
